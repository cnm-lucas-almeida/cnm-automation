import axios from 'axios';

const OMIE_APP_KEY = process.env.OMIE_APP_KEY;
const OMIE_APP_SECRET = process.env.OMIE_APP_SECRET;
const OMIE_API_URL = 'https://app.omie.com.br/api/v1/';

const omieClient = axios.create({
  baseURL: OMIE_API_URL,
  timeout: 30000, // 30s timeout para não ficar preso em conexões travadas
  headers: {
    'Content-Type': 'application/json'
  }
});

export async function listarContasReceber(pagina = 1, registrosPorPagina = 500, filtroData = null) {
  const call = "ListarContasReceber";
  const param: any[] = [
    {
      pagina,
      registros_por_pagina: registrosPorPagina,
      apenas_importado_api: "N",
      filtrar_apenas_titulos_em_aberto: "N",
      filtrar_apenas_inclusao: "N"
    }
  ];

  // Adicionar filtros de data, se fornecidos
  if (filtroData) {
      if (filtroData.data_vencimento_inicial) param[0].filtrar_por_data_de = filtroData.data_vencimento_inicial;
      if (filtroData.data_vencimento_final) param[0].filtrar_por_data_ate = filtroData.data_vencimento_final;
  }

  const payload = {
    call,
    app_key: OMIE_APP_KEY,
    app_secret: OMIE_APP_SECRET,
    param: param
  };

  try {
    const response = await omieClient.post('financas/contareceber/', payload);
    return response.data;
  } catch (error: any) {
    const details = error?.response?.data?.faultstring || error?.response?.data || error.message;
    console.error('Erro ao buscar dados na Omie:', details);
    throw new Error(`Falha na comunicação com Omie: ${typeof details === 'string' ? details : JSON.stringify(details)}`);
  }
}

export async function lancarRecebimento(params: {
  codigo_lancamento: number;
  codigo_conta_corrente: number;
  valor: number;
  data: string;
  observacao?: string;
}) {
  const payload = {
    call: "LancarRecebimento",
    app_key: OMIE_APP_KEY,
    app_secret: OMIE_APP_SECRET,
    param: [
      {
        codigo_lancamento: params.codigo_lancamento,
        codigo_baixa: 0, // 0 para novo recebimento
        codigo_conta_corrente: params.codigo_conta_corrente,
        valor: params.valor,
        data: params.data,
        observacao: params.observacao || "Baixa automática via Omie Validator"
      }
    ]
  };

  try {
    const response = await omieClient.post('financas/contareceber/', payload);
    return response.data;
  } catch (error: any) {
    const details = error?.response?.data?.faultstring || error?.response?.data || error.message;
    console.error('Erro ao lançar recebimento na Omie:', details);
    throw new Error(`Falha ao lançar recebimento: ${typeof details === 'string' ? details : JSON.stringify(details)}`);
  }
}

export async function conciliarRecebimento(codigo_baixa: number) {
  const payload = {
    call: "ConciliarRecebimento",
    app_key: OMIE_APP_KEY,
    app_secret: OMIE_APP_SECRET,
    param: [
      {
        codigo_baixa: codigo_baixa
      }
    ]
  };

  try {
    const response = await omieClient.post('financas/contareceber/', payload);
    return response.data;
  } catch (error: any) {
    const details = error?.response?.data?.faultstring || error?.response?.data || error.message;
    console.error('Erro ao conciliar recebimento na Omie:', details);
    throw new Error(`Falha ao conciliar recebimento: ${typeof details === 'string' ? details : JSON.stringify(details)}`);
  }
}

